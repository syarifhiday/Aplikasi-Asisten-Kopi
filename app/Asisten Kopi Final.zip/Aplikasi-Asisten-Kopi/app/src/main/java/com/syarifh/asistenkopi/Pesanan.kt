package com.syarifh.asistenkopi

data class Pesanan(val gula:String?=null, val status:String?=null)
